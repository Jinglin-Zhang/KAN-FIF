# -*- coding: utf-8 -*-
import os
import numpy as np
from datetime import datetime, timedelta
from torch.utils.data import Dataset, DataLoader
from Ascend_config import AscendConfig

config = AscendConfig()


class TyphoonDataset(Dataset):
    def __init__(self, data_path):
        self.samples = []
        typhoon_groups = {}

        for filename in os.listdir(data_path):
            if not filename.endswith('.npy'):
                continue

            parts = filename[:-4].split('_')
            # 解析特征
            lat = float(parts[0])
            lon = float(parts[1])
            t = float(parts[2])
            pre_category = float(parts[3])
            pressure = float(parts[4])
            wind = float(parts[5])
            rmw = float(parts[6])
            obs_time = datetime.strptime(parts[10], "%Y%m%d%H")

            # 生成样本标识 (台风名_时间)
            sample_id = f"{parts[9]}_{parts[10]}"

            key = parts[9]  # 台风名作为分组键
            if key not in typhoon_groups:
                typhoon_groups[key] = []

            typhoon_groups[key].append({
                'obs_time': obs_time,
                'features': [lat, lon, t, pre_category, pressure],
                'image_path': os.path.join(data_path, filename),
                'target': [wind, rmw],
                'sample_id': sample_id  # 存储样本标识
            })

        # 生成时间序列样本
        for typhoon, samples in typhoon_groups.items():
            samples.sort(key=lambda x: x['obs_time'])
            for i in range(len(samples) - config.seq_length + 1):
                time_points = [s['obs_time'] for s in samples[i:i + config.seq_length]]

                # 确保时间间隔为3小时
                if all((time_points[j + 1] - time_points[j]) == timedelta(hours=3)
                       for j in range(len(time_points) - 1)):
                    # 使用序列中最后一个样本作为预测目标
                    target_sample = samples[i + config.seq_length - 1]

                    self.samples.append({
                        'seq_features': [s['features'] for s in samples[i:i + config.seq_length]],
                        'image_path': target_sample['image_path'],
                        'target': target_sample['target'],
                        'sample_id': target_sample['sample_id']  # 存储样本标识
                    })

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        sample = self.samples[idx]

        # 加载图像
        image = np.load(sample['image_path']).astype(np.float32)

        # 序列特征归一化
        seq_features = []
        for feat in sample['seq_features']:
            norm_feat = [
                (feat[0] - config.feature_ranges['lat']['min']) /
                (config.feature_ranges['lat']['max'] - config.feature_ranges['lat']['min']),
                (feat[1] - config.feature_ranges['lon']['min']) /
                (config.feature_ranges['lon']['max'] - config.feature_ranges['lon']['min']),
                (feat[2] - config.feature_ranges['t']['min']) /
                (config.feature_ranges['t']['max'] - config.feature_ranges['t']['min']),
                (feat[3] - config.feature_ranges['pre_category']['min']) /
                (config.feature_ranges['pre_category']['max'] - config.feature_ranges['pre_category']['min']),
                (feat[4] - config.feature_ranges['pressure']['min']) /
                (config.feature_ranges['pressure']['max'] - config.feature_ranges['pressure']['min'])
            ]
            seq_features.append(norm_feat)

        # 目标归一化
        target = [
            (sample['target'][0] - config.feature_ranges['wind']['min']) /
            (config.feature_ranges['wind']['max'] - config.feature_ranges['wind']['min']),
            (sample['target'][1] - config.feature_ranges['RMW']['min']) /
            (config.feature_ranges['RMW']['max'] - config.feature_ranges['RMW']['min'])
        ]

        return {
            'seq': np.array(seq_features, dtype=np.float32),
            'image': image,
            'target': np.array(target, dtype=np.float32),
            'sample_id': sample['sample_id']  # 返回样本标识
        }