# -*- coding: utf-8 -*-
import math
import time
import numpy as np
from tqdm import tqdm
from torch.utils.data import DataLoader
from ais_bench.infer.interface import InferSession
from Ascend_config import AscendConfig
from Ascend_dataset import TyphoonDataset

config = AscendConfig()


def main():
    # 初始化数据集
    dataset = TyphoonDataset(config.test_data_path)
    dataloader = DataLoader(dataset, batch_size=config.batch_size, shuffle=False)

    # 加载模型
    model = InferSession(device_id=0, model_path=config.om_model_path)

    # 初始化统计量
    wind_mae = wind_rmse = rmw_mae = rmw_rmse = 0.0
    total_time = 0
    sample_count = 0

    # 测试循环
    for batch in tqdm(dataloader):
        # 准备输入
        seq_input = batch['seq'].numpy().astype(np.float32)
        img_input = batch['image'].numpy().astype(np.float32)
        seq_input = np.ascontiguousarray(seq_input)
        img_input = np.ascontiguousarray(img_input)

        # 推理
        start_time = time.time()
        outputs = model.infer([seq_input, img_input])
        infer_time = time.time() - start_time

        # 解析输出
        wind_pred = outputs[0][0]
        rmw_pred = outputs[1][0]

        # 反归一化
        wind_true = batch['target'][0][0].item() * (170 - 19) + 19
        wind_pred = wind_pred * (170 - 19) + 19
        rmw_true = batch['target'][0][1].item() * (200 - 5) + 5
        rmw_pred = rmw_pred * (200 - 5) + 5

        # 累计统计
        sample_count += 1
        total_time += infer_time

        wind_mae += np.abs(wind_pred - wind_true)
        wind_rmse += (wind_pred - wind_true) ** 2
        rmw_mae += np.abs(rmw_pred - rmw_true)
        rmw_rmse += (rmw_pred - rmw_true) ** 2

    # 计算最终指标
    wind_mae /= sample_count
    wind_rmse = math.sqrt(wind_rmse / sample_count)
    rmw_mae /= sample_count
    rmw_rmse = math.sqrt(rmw_rmse / sample_count)
    avg_infer_time = total_time / sample_count

    # 打印测试结果
    print(f"\n=== 部署测试结果 ===")
    print(f"样本总数: {sample_count}")
    print(f"平均推理时间: {avg_infer_time * 1000:.2f}ms/样本")
    print("\n--- 精度指标 ---")
    print(f"Wind MAE: {wind_mae:.2f}")
    print(f"Wind RMSE: {wind_rmse:.2f}")
    print(f"RMW MAE: {rmw_mae:.2f}")
    print(f"RMW RMSE: {rmw_rmse:.2f}")


if __name__ == "__main__":
    main()