# -*- coding: utf-8 -*-
import os


class AscendConfig:
    # 获取项目根目录（KAN-FIF-github）
    project_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    # 路径配置（相对于项目根目录）
    om_model_path = os.path.join(project_path, "models", "deploy.om")
    test_data_path = os.path.join(project_path, "data", "test")
    # test_data_path = os.path.join(project_path, "data", "SURIGAE_2021042103")

    # 数据参数
    seq_length = 3
    batch_size = 1
    num_workers = 0

    # 归一化参数（必须与训练时一致）
    feature_ranges = {
        'lat': {'min': -32.0377, 'max': 44.9},
        'lon': {'min': 86.27, 'max': 193.7},
        't': {'min': 3.0, 'max': 387.0},
        'pre_category': {'min': -1, 'max': 5},
        'pressure': {'min': 922.0, 'max': 1006.0},
        'wind': {'min': 19, 'max': 170},
        'RMW': {'min': 5, 'max': 200}
    }

    # 输入节点名称（根据onnx导出时定义）
    input_names = {
        "seq_input": "seq_input",
        "img_input": "img_input"
    }