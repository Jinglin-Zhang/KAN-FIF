# kan.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import math


class KANLinear(nn.Module):
    def __init__(
            self,
            in_features,
            out_features,
            grid_size=5,
            spline_order=3,
            scale_noise=0.1,
            scale_base=1.0,
            scale_spline=1.0,
            enable_standalone_scale_spline=True,
            base_activation=nn.SiLU,
            grid_eps=0.02,
            grid_range=[-1, 1],
    ):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.grid_size = grid_size
        self.spline_order = spline_order

        # 网格初始化（固定不可训练）
        h = (grid_range[1] - grid_range[0]) / grid_size
        grid = (
                torch.arange(-spline_order, grid_size + spline_order + 1) * h
                + grid_range[0]
        ).expand(in_features, -1).contiguous()
        self.register_buffer("grid", grid)

        # 可训练参数
        self.base_weight = nn.Parameter(torch.Tensor(out_features, in_features))
        self.spline_weight = nn.Parameter(
            torch.Tensor(out_features, in_features, grid_size + spline_order)
        )
        if enable_standalone_scale_spline:
            self.spline_scaler = nn.Parameter(torch.Tensor(out_features, in_features))

        # 初始化参数
        self.scale_noise = scale_noise
        self.scale_base = scale_base
        self.scale_spline = scale_spline
        self.enable_standalone_scale_spline = enable_standalone_scale_spline
        self.base_activation = base_activation()
        self.grid_eps = grid_eps
        self.reset_parameters()

    def reset_parameters(self):
        # 基础权重初始化
        nn.init.kaiming_uniform_(self.base_weight, a=math.sqrt(5) * self.scale_base)

        # 样条权重初始化
        with torch.no_grad():
            # 确保noise在正确的设备上生成
            noise = (
                    (torch.rand(self.grid_size + 1, self.in_features, self.out_features, device=self.grid.device) - 0.5)
                    * self.scale_noise / self.grid_size
            )
            self.spline_weight.data.copy_(self.curve2coeff(
                self.grid.T[self.spline_order: -self.spline_order],
                noise
            ))

        # 样条缩放参数初始化
        if self.enable_standalone_scale_spline:
            nn.init.kaiming_uniform_(self.spline_scaler, a=math.sqrt(5) * self.scale_spline)

    def b_splines(self, x: torch.Tensor):
        """
        输入: (batch, in_features)
        输出: (batch, in_features, grid_size + spline_order)
        """
        # print("111")
        # print(x.shape)
        # assert x.dim() == 2 and x.size(1) == self.in_features
        grid: torch.Tensor = self.grid  # (in_features, grid_size + 2*spline_order + 1)

        x = x.unsqueeze(-1)
        bases = ((x >= grid[:, :-1]) & (x < grid[:, 1:])).to(x.dtype)

        # 递推计算B样条基函数
        for k in range(1, self.spline_order + 1):
            bases = (x - grid[:, :-(k + 1)]) / (grid[:, k:-1] - grid[:, :-(k + 1)] + 1e-8) * bases[:, :, :-1] + \
                    (grid[:, k + 1:] - x) / (grid[:, k + 1:] - grid[:, 1:-k] + 1e-8) * bases[:, :, 1:]

        return bases.contiguous()

    def curve2coeff(self, x: torch.Tensor, y: torch.Tensor):
        """
        输入:
            x: (batch, in_features)
            y: (batch, in_features, out_features)
        输出:
            coeff: (out_features, in_features, grid_size + spline_order)
        """
        A = self.b_splines(x).transpose(0, 1)  # (in_features, batch, coeff)
        B = y.transpose(0, 1)  # (in_features, batch, out_features)

        # 最小二乘解
        solution = torch.linalg.lstsq(A, B).solution
        return solution.permute(2, 0, 1).contiguous()

    @property
    def scaled_spline_weight(self):
        return self.spline_weight * (
            self.spline_scaler.unsqueeze(-1)
            if self.enable_standalone_scale_spline
            else 1.0
        )

    def forward(self, x: torch.Tensor):
        """
        输入: (batch, in_features)
        输出: (batch, out_features)
        """
        # 基础路径
        base_output = F.linear(self.base_activation(x), self.base_weight)  # (batch, out_features)

        # 样条路径
        spline_output = F.linear(
            self.b_splines(x).view(x.size(0), -1),  # (batch, in_features*(grid_size + spline_order))
            (self.scaled_spline_weight.view(self.out_features, -1))
            # (out_features, in_features*(grid_size + spline_order))
        )

        return base_output + spline_output


class KAN(nn.Module):
    def __init__(self, layers_hidden, grid_size=5, **kwargs):
        super().__init__()
        self.layers = nn.ModuleList()
        for in_feat, out_feat in zip(layers_hidden, layers_hidden[1:]):
            self.layers.append(KANLinear(
                in_feat, out_feat,
                grid_size=grid_size,
                **kwargs
            ))

    def forward(self, x: torch.Tensor):
        for layer in self.layers:
            x = layer(x)
        return x