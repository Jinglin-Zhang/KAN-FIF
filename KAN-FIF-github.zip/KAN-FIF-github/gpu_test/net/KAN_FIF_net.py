import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from net.kan import KANLinear, KAN


class Shared_Network_KANLSTM(nn.Module):
    def __init__(self, input_size=5, lstm_hidden=64, kan_hidden=[128, 32], use_kan=True):
        super().__init__()
        self.lstm_hidden = lstm_hidden
        self.lstm = nn.LSTM(input_size, lstm_hidden, batch_first=True)

        # 维度校正: LSTM输出 -> KAN输入
        self.kan_stack = KAN([lstm_hidden, kan_hidden[0], kan_hidden[1]], grid_size=5) if use_kan else \
            nn.Sequential(
                nn.Linear(lstm_hidden, kan_hidden[0]),
                nn.ReLU(),
                nn.Linear(kan_hidden[0], kan_hidden[1])
            )

    def forward(self, x):
        # 显式初始化隐藏状态
        h0 = torch.zeros(1, x.size(0), self.lstm_hidden).to(x.device)
        c0 = torch.zeros(1, x.size(0), self.lstm_hidden).to(x.device)
        # x形状: [B, seq_len=3, features=5]
        _, (hidden, _) = self.lstm(x, (h0, c0))
        lstm_out = hidden[-1]  # 取最后隐藏状态 [B, 64]
        return self.kan_stack(lstm_out)  # [B, 32]


class MultiScaleConvBlock(nn.Module):
    def __init__(self, in_channels=8, base_channels=16):
        super().__init__()
        # 主干路径
        self.main_conv = nn.Sequential(
            nn.Conv2d(in_channels, base_channels, 5, stride=2, padding=2),  # [B,16,78,78]
            nn.ReLU(),
            nn.MaxPool2d(3, stride=2, padding=1),  # [B,16,39,39]

            nn.Conv2d(base_channels, base_channels * 2, 3, stride=2, padding=1),  # [B,32,20,20]
            nn.ReLU(),
            nn.MaxPool2d(3, stride=2, padding=1)  # [B,32,10,10]
        )

        # 多尺度分支（固定kernel）
        self.multiscale = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(32, 32, 3, dilation=d, padding=d),
                nn.ReLU()
            ) for d in [1, 2, 3]
        ])

        # 残差路径
        self.res_conv = nn.Conv2d(32, 64, 1)  # [B,64,10,10]

        # 固定参数池化替代AdaptiveAvgPool
        self.fusion = nn.Sequential(
            nn.AvgPool2d(5, stride=5),  # [B,160,10,10] -> [B,160,2,2]
            nn.Conv2d(160, 64, 1)  # [B,64,2,2]
        )

    def forward(self, x):
        x_main = self.main_conv(x)  # [B,32,10,10]
        # 多尺度特征提取
        scale_feats = [conv(x_main) for conv in self.multiscale]  # 3*[B,32,10,10]
        # 残差连接
        res = self.res_conv(x_main)  # [B,64,10,10]
        # 特征融合
        combined = torch.cat(scale_feats + [res], dim=1)  # [B,160,10,10]
        return self.fusion(combined)  # [B,64,2,2]


class Shared_Network_KANCNN(nn.Module):
    def __init__(self, kan_hidden=[256, 32], use_kan=True):
        super().__init__()
        self.conv_block = MultiScaleConvBlock()  # 输出[B,64,2,2]

        # 展平后的维度校正
        self.compress = nn.Sequential(
            nn.Flatten(),  # [B,64 * 2 * 2=256]
            KAN([256, kan_hidden[0], kan_hidden[1]], grid_size=5) if use_kan else \
                nn.Sequential(
                    nn.Linear(256, kan_hidden[0]),
                    nn.ReLU(),
                    nn.Linear(kan_hidden[0], kan_hidden[1])
                )
        )

    def forward(self, x):
        # x形状: [B,8,156,156]
        x = self.conv_block(x)  # [B,64,2,2]
        return self.compress(x)  # [B,32]


class CenterAwareCrossAttention(nn.Module):
    def __init__(self, feat_dim=32, num_heads=4, use_kan=True):
        super().__init__()
        self.num_heads = num_heads
        self.head_dim = feat_dim // num_heads
        assert feat_dim % num_heads == 0, "feat_dim必须能被num_heads整除"

        # 固定参数池化网格（修正网格生成逻辑）
        self.register_buffer('roi_grid', torch.linspace(0, 1, 39).view(39, 1))

        # 使用KAN替代线性层（严格匹配输入输出维度）
        self.k_layer = KANLinear(1, feat_dim, grid_size=5) if use_kan else \
            nn.Sequential(
                nn.Linear(1, 5),  # 扩展中间维度
                nn.Tanh(),  # 使用tanh激活
                nn.Linear(5, feat_dim)  # 映射到目标维度
            )
        self.qv_layer = KANLinear(4, 2 * feat_dim, grid_size=5) if use_kan else \
            nn.Sequential(
                nn.Linear(4, 8),  # 扩展中间维度
                nn.Tanh(),  # 使用tanh激活
                nn.Linear(8, 2 * feat_dim)  # 映射到双倍维度
            )

        self.proj = KANLinear(64, feat_dim, grid_size=5) if use_kan else nn.Linear(64, feat_dim)

    def forward(self, lstm_feat, image):
        B = image.size(0)
        spatial_feat = image[:, 6:7]  # 提取空间特征 [B,1,156,156]

        center = 77

        pool_stack = []
        for i in range(0, 39):
            # 计算当前环形区域的边界
            L = center - 2 * i
            R = center + 2 * i + 2
            roi = spatial_feat[:, :, L:R, L:R]  # 提取环形区域

            # 根据区域大小选择池化策略
            h = R - L  # 当前区域边长
            if h <= 63:  # 小半径直接池化
                pool = F.avg_pool2d(roi, kernel_size=h // 2, stride=h // 2)
            else:  # 大半径分阶段池化
                # 第一阶段池化
                pool = F.avg_pool2d(roi, kernel_size=h // 4, stride=h // 4)
                # 第二阶段池化
                pool = F.avg_pool2d(pool, kernel_size=2, stride=2)

            pool_stack.append(pool.view(B, 4))

        cinfo = torch.stack(pool_stack, dim=1).view(-1, 4)  # [B,39,4]
        roi_grid = self.roi_grid  # [39,1]

        k = self.k_layer(roi_grid).expand(B, -1, -1)  # [B,39,32]
        qv = self.qv_layer(cinfo).view(B, 39, 2, -1).permute(2, 0, 1, 3)  # [2,B,39,32]
        q, v = qv[0], qv[1]  # 各[B,39,32]

        # 多头处理（精确控制维度变换）H=8 N=4
        k = k.view(B, 39, self.num_heads, self.head_dim).permute(0, 2, 1, 3)  # [B,H,39,D]
        q = q.view(B, 39, self.num_heads, self.head_dim).permute(0, 2, 1, 3)  # [B,H,39,D]
        v = v.view(B, 39, self.num_heads, self.head_dim).permute(0, 2, 1, 3)  # [B,H,39,D]

        # 注意力计算（保持矩阵乘法维度一致性）
        attn = (q @ k.transpose(-2, -1)) / math.sqrt(self.head_dim)  # [B,H,39,39]
        attn = F.softmax(attn, dim=-1)
        x = (attn @ v).transpose(1, 2).reshape(B, 39, -1)  # [B,39,32]

        combined = torch.cat([x.mean(dim=1), lstm_feat], dim=-1)  #[B,32]+[B,32]

        return self.proj(combined)  # [B,32]


class PeRCNNuv_RTV(nn.Module):
    def __init__(self, channels):
        super(PeRCNNuv_RTV, self).__init__()
        self.channels = channels
        self.real_c1 = nn.Conv2d(in_channels=channels, out_channels=channels, kernel_size=1)
        self.real_c2 = nn.Conv2d(in_channels=channels, out_channels=channels, kernel_size=1)
        self.real_c3 = nn.Conv2d(in_channels=channels, out_channels=channels, kernel_size=1)
        self.real_conv = nn.Conv1d(in_channels=4, out_channels=4, kernel_size=1)

        self.imag_c1 = nn.Conv2d(in_channels=channels, out_channels=channels, kernel_size=1)
        self.imag_c2 = nn.Conv2d(in_channels=channels, out_channels=channels, kernel_size=1)
        self.imag_c3 = nn.Conv2d(in_channels=channels, out_channels=channels, kernel_size=1)
        self.imag_conv = nn.Conv1d(in_channels=4, out_channels=4, kernel_size=1)
        self.relu = nn.ReLU()

    def forward(self, x):
        # 通过傅立叶变换，将x映射到频率和相位两个分量
        B, C, H, W = x.shape  # B, 64, 2, 2

        # r_x = x[0].cpu().sum(dim=0).detach().numpy()
        # plt.imsave("/data/yht/r_x.png", r_x)

        x = x.reshape(B, H, W, C)  # B, 2, 2, 64
        x = torch.fft.rfft2(x, dim=(1, 2), norm="ortho")  # B, 2, 2, 64   (2/2+1=8)

        x_real = x.real  # B, 2, 2, 64
        x_real = x_real.reshape(B, C, H, W)  # B, 64, 2, 2
        x_imag = x.imag  # B, 2, 2, 64
        x_imag = x_imag.reshape(B, C, H, W)  # B, 64, 2, 2

        # rx_real = x_real.cpu().sum(dim=1).detach().numpy()[0]
        # plt.imsave("/data/yht/rx_real.png", rx_real)
        # rx_image = x_imag.cpu().sum(dim=1).detach().numpy()[0]
        # plt.imsave("/data/yht/rx_image.png", rx_image)

        x1_real = self.real_c1(x_real)
        x1_real = self.relu(x1_real)
        x2_real = self.real_c2(x_real)
        x2_real = self.relu(x2_real)
        x3_real = self.real_c3(x_real)
        x3_real = self.relu(x3_real)
        # b, 353 or 64, 2, 2
        x_pole_real = x1_real * x2_real * x3_real

        x_pole_real = x_pole_real.reshape(B, C, 4)
        x_pole_real = x_pole_real.transpose(1, 2)

        x_pole_real = self.real_conv(x_pole_real)
        x_pole_real = self.relu(x_pole_real)

        x_pole_real = x_pole_real.transpose(1, 2)
        x_pole_real = x_pole_real.reshape(B, C, 2, 2)

        # rx_real = x_real.cpu().sum(dim=1).detach().numpy()[0]
        # plt.imsave("/data/yht/rx_real.png", rx_real)

        x_pole_real = x_pole_real.reshape(B, H, W, C)  # B, 2, 2, 64

        x1_imag = self.imag_c1(x_imag)
        x1_imag = self.relu(x1_imag)
        x2_imag = self.imag_c2(x_imag)
        x2_imag = self.relu(x2_imag)
        x3_imag = self.imag_c3(x_imag)
        x3_imag = self.relu(x3_imag)
        # b, 353 or 64, 2, 2
        x_pole_imag = x1_imag * x2_imag * x3_imag

        x_pole_imag = x_pole_imag.reshape(B, C, 4)
        x_pole_imag = x_pole_imag.transpose(1, 2)

        x_pole_imag = self.imag_conv(x_pole_imag)
        x_pole_imag = self.relu(x_pole_imag)

        x_pole_imag = x_pole_imag.transpose(1, 2)
        x_pole_imag = x_pole_imag.reshape(B, C, 2, 2)

        # rx_image = x_imag.cpu().sum(dim=1).detach().numpy()[0]
        # plt.imsave("/data/yht/rx_image.png", rx_image)

        x_pole_imag = x_pole_imag.reshape(B, H, W, C)  # B, 2, 2, 64

        x_ploe = torch.stack([x_pole_real, x_pole_imag], dim=-1)  # B, 2, 2, 64, 2
        x_ploe = F.softshrink(x_ploe, lambd=0.01)
        x_ploe = torch.view_as_complex(x_ploe)  # 将输入x变成复数张量： B, 2, 2, 64
        x_ploe = torch.fft.irfft2(x_ploe, s=(H, W), dim=(1, 2), norm="ortho")  # B, 2, 2, 64
        x_ploe = x_ploe.reshape(B, C, H, W)  # B, 64, 2, 2

        # x_ploe = self.w1 * x_res + x_ploe

        # bias = nn.Parameter(torch.tensor((np.random.rand(bs, self.channels, 2, 2)), dtype=torch.float32), requires_grad=True).to(config.device)

        return x_ploe


class FourierConstraint(nn.Module):
    def __init__(self, feat_dim=32):
        super().__init__()
        # 维度调整：将向量特征映射到2D空间进行傅里叶操作
        self.expand = nn.Linear(feat_dim, 64 * 2 * 2)  # [B,32] -> [B,256]
        # 傅里叶特征处理器(来自PCCNet的改进版本)
        self.fourier_processor = nn.Sequential(
            nn.Conv2d(64, 64, 1),  # 保持通道数一致
            nn.ReLU(),
            PeRCNNuv_RTV(64),  # 使用PCCNet的傅里叶模块
            nn.Conv2d(64, 64, 1)  # 最后调整通道
        )
        # 维度压缩回原始特征空间
        self.compress = nn.Linear(64 * 2 * 2, feat_dim)  # [B,256] -> [B,32]

    def forward(self, x):
        # identity = x  # 残差连接保留原始输入 [B,32]

        # 扩展为2D特征图 [B,32] -> [B,64,2,2]
        x = self.expand(x)  # [B,256]
        x = x.view(-1, 64, 2, 2)  # 调整为适合傅里叶处理的形状

        # 傅里叶域处理 [B,64,2,2] -> [B,64,2,2]
        x = self.fourier_processor(x)

        # 压缩回向量空间 [B,64,2,2] -> [B,32]
        x = x.view(-1, 64 * 2 * 2)  # [B,256]
        x = self.compress(x)  # [B,32]
        return x

        # return identity + x  # 残差连接


class PhysicsConstraint(nn.Module):
    def __init__(self, feat_dim=32, use_kan=True):
        super().__init__()
        self.kan = KANLinear(feat_dim, feat_dim, grid_size=5) if use_kan else \
            FourierConstraint(feat_dim)  # 使用新定义的傅里叶模块

    def forward(self, x):
        return x + self.kan(x)


class KAN_FIF_net(nn.Module):
    def __init__(self, use_kan=True, kan_hidden=[64, 32], lstm_hidden=64):
        super().__init__()
        # 共享特征提取
        self.shared_lstm = Shared_Network_KANLSTM(use_kan=use_kan)
        self.shared_cnn = Shared_Network_KANCNN(use_kan=use_kan)
        # self.shared_lstm = Shared_Network_KANLSTM(use_kan=False)
        # self.shared_cnn = Shared_Network_KANCNN(use_kan=False)


        # 注意力模块
        self.wind_attention = CenterAwareCrossAttention(use_kan=use_kan)
        self.rmw_attention = CenterAwareCrossAttention(use_kan=use_kan)
        # # # 注意力模块
        # self.wind_attention = CenterAwareCrossAttention(use_kan=False)
        # self.rmw_attention = CenterAwareCrossAttention(use_kan=False)

        # 物理约束
        self.wind_to_rmw = PhysicsConstraint(use_kan=use_kan)
        self.rmw_to_wind = PhysicsConstraint(use_kan=use_kan)
        # self.wind_to_rmw = PhysicsConstraint(use_kan=False)
        # self.rmw_to_wind = PhysicsConstraint(use_kan=False)


        # 解码器
        self.wind_decoder = KANLinear(128, 1, grid_size=5) if use_kan else nn.Linear(128, 1)
        self.rmw_decoder = KANLinear(128, 1, grid_size=5) if use_kan else nn.Linear(128, 1)
        # self.wind_decoder = nn.Linear(128, 1)
        # self.rmw_decoder = nn.Linear(128, 1)

    def forward(self, seq, image):
        # 特征提取
        lstm_feat = self.shared_lstm(seq)  # [B,32]
        cnn_feat = self.shared_cnn(image)  # [B,32]
        shared_feat = torch.cat([lstm_feat, cnn_feat], dim=1)  # [B,64]

        # 注意力
        wind_attn = self.wind_attention(lstm_feat, image)  # [B,32]
        rmw_attn = self.rmw_attention(lstm_feat, image)  # [B,32]

        # 物理约束
        wind2rmw = self.wind_to_rmw(wind_attn)  # [B,32]
        rmw2wind = self.rmw_to_wind(rmw_attn)  # [B,32]

        # 特征融合（32+32+64=128）
        wind_final = torch.cat([wind_attn, rmw2wind, shared_feat], dim=1)
        rmw_final = torch.cat([rmw_attn, wind2rmw, shared_feat], dim=1)

        # 预测
        wind_pred = self.wind_decoder(wind_final).squeeze(1)
        rmw_pred = self.rmw_decoder(rmw_final).squeeze(1)
        return wind_pred, rmw_pred
