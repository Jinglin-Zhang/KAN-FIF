import os
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from datetime import datetime, timedelta


class TyphoonDataset(Dataset):
    def __init__(self, data_path, seq_length=3, data_format='npy'):
        self.seq_length = seq_length
        self.samples = []

        # 存储所有特征的最大最小值（用于归一化）
        self.feature_ranges = {
            'lat': {'min': -32.0377, 'max': 44.9},
            'lon': {'min': 86.27, 'max': 193.7},
            't': {'min': float('inf'), 'max': float('-inf')},
            'pre_category': {'min': -1, 'max': 5},
            'pressure': {'min': float('inf'), 'max': float('-inf')},
            'wind': {'min': 19, 'max': 170},
            'RMW': {'min': 5, 'max': 200}
        }

        # 按台风和旋转类型分组
        typhoon_groups = {}
        for filename in os.listdir(data_path):
            if not filename.endswith('.npy'):
                continue

            # 解析文件名
            parts = filename[:-4].split('_')
            rotation = 'none'
            if 'rotate' in parts[-1]:
                rotation = parts[-1]
                parts = parts[:-1]

            # 提取特征
            lat = float(parts[0])
            lon = float(parts[1])
            t = float(parts[2])
            pre_category = float(parts[3])
            pressure = float(parts[4])
            wind = float(parts[5])
            rmw = float(parts[6])
            typhoon_name = parts[9]
            obs_time = datetime.strptime(parts[10], "%Y%m%d%H")

            # 更新特征范围
            self._update_range('t', t)
            self._update_range('pressure', pressure)

            # 按台风名和旋转类型分组
            key = (typhoon_name, rotation)
            if key not in typhoon_groups:
                typhoon_groups[key] = []
            typhoon_groups[key].append({
                'obs_time': obs_time,
                'features': [lat, lon, t, pre_category, pressure],
                'image_path': os.path.join(data_path, filename),
                'target': [wind, rmw]
            })

        # # 输出归一化参数
        # print("Feature Normalization Parameters:")
        # for feat in ['lat', 'lon', 't', 'pre_category', 'pressure', 'wind', 'RMW']:
        #     print(f"{feat}: min={self.feature_ranges[feat]['min']:.4f}, max={self.feature_ranges[feat]['max']:.4f}")

        # 生成时间序列样本
        for (typhoon, rotation), samples in typhoon_groups.items():
            # 按时间排序
            samples.sort(key=lambda x: x['obs_time'])

            # 生成序列
            for i in range(len(samples) - self.seq_length + 1):
                time_points = [s['obs_time'] for s in samples[i:i + self.seq_length]]
                # 验证时间间隔
                if all((time_points[j + 1] - time_points[j]) == timedelta(hours=3)
                       for j in range(len(time_points) - 1)):
                    self.samples.append({
                        'seq_features': [s['features'] for s in samples[i:i + self.seq_length]],
                        'image_path': samples[i + self.seq_length - 1]['image_path'],
                        'target': samples[i + self.seq_length - 1]['target']
                    })

    def _update_range(self, feat, value):
        self.feature_ranges[feat]['min'] = min(self.feature_ranges[feat]['min'], value)
        self.feature_ranges[feat]['max'] = max(self.feature_ranges[feat]['max'], value)

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        sample = self.samples[idx]

        # 加载并归一化图像数据
        image = np.load(sample['image_path']).astype(np.float32)

        # 归一化序列特征
        seq_features = []
        for time_step in sample['seq_features']:
            norm_feat = [
                (time_step[0] - self.feature_ranges['lat']['min']) / (
                            self.feature_ranges['lat']['max'] - self.feature_ranges['lat']['min']),
                (time_step[1] - self.feature_ranges['lon']['min']) / (
                            self.feature_ranges['lon']['max'] - self.feature_ranges['lon']['min']),
                (time_step[2] - self.feature_ranges['t']['min']) / (
                            self.feature_ranges['t']['max'] - self.feature_ranges['t']['min']),
                (time_step[3] - self.feature_ranges['pre_category']['min']) / (
                            self.feature_ranges['pre_category']['max'] - self.feature_ranges['pre_category']['min']),
                (time_step[4] - self.feature_ranges['pressure']['min']) / (
                            self.feature_ranges['pressure']['max'] - self.feature_ranges['pressure']['min'])
            ]
            seq_features.append(norm_feat)

        # 归一化目标值
        target = [
            (sample['target'][0] - self.feature_ranges['wind']['min']) / (
                        self.feature_ranges['wind']['max'] - self.feature_ranges['wind']['min']),
            (sample['target'][1] - self.feature_ranges['RMW']['min']) / (
                        self.feature_ranges['RMW']['max'] - self.feature_ranges['RMW']['min'])
        ]

        return {
            'seq': torch.FloatTensor(seq_features),
            'image': torch.FloatTensor(image),
            'target': torch.FloatTensor(target),
            'pressure': torch.FloatTensor([time_step[4]]) , # 添加气压数据
            'image_path': sample['image_path']

        }


# 测试代码
if __name__ == "__main__":
    dataset = TyphoonDataset(r"D:\pycharm_code\TC\my_TC\data\small_train201507")
    print(f"Total samples: {len(dataset)}")
    sample = dataset[0]
    print(f"Sequence shape: {sample['seq'].shape}")  # torch.Size([3, 5])
    print(f"Image shape: {sample['image'].shape}")  # torch.Size([8, 156, 156])