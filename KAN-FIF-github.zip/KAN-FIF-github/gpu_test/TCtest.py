# TCtest.py
import time
import math
import os
import torch
from torch.utils.data import DataLoader
# from dataset_no_seq import TyphoonDataset
# from net.KAN_FIF_net_no_seq import KAN_FIF_net
from dataset import TyphoonDataset
from net.KAN_FIF_net import KAN_FIF_net
from config import TrainConfig, DataConfig, PathConfig, device

# 获取项目根目录并构建模型路径
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
test_model_path = os.path.join(_project_root, "models", "checkpoint_20_scheduled_05191037.pth")


def test_model(model, test_loader):
    model.eval()
    total_samples = 0
    inference_time = 0.0

    # 初始化误差统计
    wind_mae = 0.0
    wind_rmse = 0.0
    rmw_mae = 0.0
    rmw_rmse = 0.0

    with torch.no_grad():
        start_time = time.time()
        for batch in test_loader:
            seq = batch['seq'].to(device)
            image = batch['image'].to(device)
            target = batch['target'].to(device)
            pressure = batch['pressure'].to(device)

            # 推理计时
            batch_start = time.time()
            wind_pred, rmw_pred = model(seq, image)
            torch.cuda.synchronize()
            batch_end = time.time()
            inference_time += (batch_end - batch_start)

            # 反归一化处理
            wind_pred = wind_pred * (170 - 19) + 19
            wind_true = target[:, 0] * (170 - 19) + 19
            rmw_pred = rmw_pred * (200 - 5) + 5
            rmw_true = target[:, 1] * (200 - 5) + 5

            # 累计统计量
            batch_samples = seq.size(0)
            total_samples += batch_samples

            wind_mae += torch.sum(torch.abs(wind_pred - wind_true)).item()
            wind_rmse += torch.sum((wind_pred - wind_true) ** 2).item()
            rmw_mae += torch.sum(torch.abs(rmw_pred - rmw_true)).item()
            rmw_rmse += torch.sum((rmw_pred - rmw_true) ** 2).item()

        total_time = time.time() - start_time

    # 计算最终指标
    wind_mae /= total_samples
    wind_rmse = math.sqrt(wind_rmse / total_samples)
    rmw_mae /= total_samples
    rmw_rmse = math.sqrt(rmw_rmse / total_samples)

    return {
        "wind_mae": wind_mae,
        "wind_rmse": wind_rmse,
        "rmw_mae": rmw_mae,
        "rmw_rmse": rmw_rmse,
        "total_samples": total_samples,
        "total_time": total_time,
        "avg_inference_time": inference_time / total_samples if total_samples else 0
    }


if __name__ == "__main__":
    # 初始化测试数据集
    test_dataset = TyphoonDataset(DataConfig.test_path, DataConfig.seq_length)
    test_loader = DataLoader(
        test_dataset,
        batch_size=DataConfig.batch_size,
        shuffle=False,
        num_workers=0,
        pin_memory=True
    )

    # 加载部署版模型
    model = KAN_FIF_net(
        use_kan=True  # True/False
    ).to(device)

    # 加载训练好的权重
    checkpoint = torch.load(test_model_path, map_location=device)
    model.load_state_dict(checkpoint['model_state_dict'])

    # 统计参数量
    total_params = sum(p.numel() for p in model.parameters())

    # 执行测试
    results = test_model(model, test_loader)

    # 打印结果报告
    print(f"=== 模型测试报告 ===")
    print(f"模型参数量: {total_params / 1e6:.2f}M")
    print(f"测试样本数量: {results['total_samples']}")
    print(f"总耗时: {results['total_time']:.2f}秒")
    print(f"平均推理时间: {results['avg_inference_time'] * 1000:.2f}ms/样本")
    print("\n--- 精度指标 ---")
    print(f"Wind MAE: {results['wind_mae']:.2f}")
    print(f"Wind RMSE: {results['wind_rmse']:.2f}")
    print(f"RMW MAE: {results['rmw_mae']:.2f}")
    print(f"RMW RMSE: {results['rmw_rmse']:.2f}")
