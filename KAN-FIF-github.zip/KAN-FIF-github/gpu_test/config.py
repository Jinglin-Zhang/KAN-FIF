# config.py
import torch
import os

# 获取项目根目录（KAN-FIF-github）
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

class DataConfig:
    # 数据路径（相对于项目根目录）
    train_path = os.path.join(_project_root, "data", "train")
    valid_path = os.path.join(_project_root, "data", "valid")
    test_path = os.path.join(_project_root, "data", "test")
    batch_size = 128
    seq_length = 3  # 时序数据时间步长

class TrainConfig:
    epochs = 200
    lr = 0.001
    loss_weights = [0.3, 0.7]  # [wind_loss_weight, rmw_loss_weight]
    early_stop_threshold = 0.01  # 验证损失阈值
    save_interval = 10  # 模型保存间隔
    resume_training = False  # 是否继续训练 True/False
    resume_model_path = None  # 继续训练时指定checkpoint路径
    reg_weight = 0.01

class PathConfig:
    # 模型和图片保存路径（相对于项目根目录）
    model_save_path = os.path.join(_project_root, "models", "checkpoints")
    fig_save_path = os.path.join(_project_root, "figs")

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")