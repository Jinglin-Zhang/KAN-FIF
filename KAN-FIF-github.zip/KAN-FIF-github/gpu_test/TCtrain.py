import time
import datetime
import matplotlib.pyplot as plt
import os
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from dataset import TyphoonDataset
from net.KAN_FIF_net import KAN_FIF_net
from config import DataConfig, TrainConfig, PathConfig, device


def train():
    # 创建基础目录（使用_deploy路径）
    os.makedirs(PathConfig.model_save_path, exist_ok=True)  # 修改点2
    os.makedirs(PathConfig.fig_save_path, exist_ok=True)     # 修改点2

    # 初始化数据集
    train_dataset = TyphoonDataset(DataConfig.train_path, DataConfig.seq_length)
    valid_dataset = TyphoonDataset(DataConfig.valid_path, DataConfig.seq_length)

    train_loader = DataLoader(train_dataset, batch_size=DataConfig.batch_size, shuffle=True)
    valid_loader = DataLoader(valid_dataset, batch_size=DataConfig.batch_size, shuffle=False)

    model = KAN_FIF_net(
        use_kan=False  #True/False
    ).to(device)

    optimizer = torch.optim.Adam(model.parameters(), lr=TrainConfig.lr)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=0.5, patience=5, min_lr=0.0001
    )
    criterion = nn.L1Loss()

    # 训练状态初始化
    start_epoch = 0
    train_losses, valid_losses = [], []
    run_dir = PathConfig.model_save_path  # 使用部署版路径

    # 恢复训练逻辑（需要确保resume_model_path指向_deploy路径）
    if TrainConfig.resume_training and os.path.exists(TrainConfig.resume_model_path):
        checkpoint = torch.load(TrainConfig.resume_model_path)
        model.load_state_dict(checkpoint['model_state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        start_epoch = checkpoint['epoch'] + 1

        train_losses = [t.item() if isinstance(t, torch.Tensor) else t
                        for t in checkpoint['train_losses']]
        valid_losses = [t.item() if isinstance(t, torch.Tensor) else t
                        for t in checkpoint['valid_losses']]

        run_dir = os.path.dirname(TrainConfig.resume_model_path)
        print(f"Loaded checkpoint from epoch {checkpoint['epoch']}")
    else:
        # 创建带有时间戳和_deploy后缀的目录
        timestamp = datetime.datetime.now().strftime("%m%d%H%M")
        run_dir = os.path.join(PathConfig.model_save_path, timestamp)   # 修改点2
        os.makedirs(run_dir, exist_ok=True)

    # 训练循环
    for epoch in range(start_epoch, TrainConfig.epochs):
        model.train()
        epoch_loss = 0.0

        # 训练步骤
        for batch in train_loader:
            seq = batch['seq'].to(device)
            image = batch['image'].to(device)
            target = batch['target'].to(device)
            pressure = batch['pressure'].to(device)

            optimizer.zero_grad()
            wind_pred, rmw_pred = model(seq, image)

            # reg_loss = model.regularization_loss(regularize_activation=0.1, regularize_entropy=0.1)
            loss = TrainConfig.loss_weights[0] * criterion(wind_pred, target[:, 0]) + \
                   TrainConfig.loss_weights[1] * criterion(rmw_pred, target[:, 1])
            total_loss = loss
            total_loss.backward()
            optimizer.step()
            epoch_loss += total_loss.item()

        avg_train_loss = epoch_loss / len(train_loader)
        train_losses.append(avg_train_loss)

        # 验证步骤
        model.eval()
        valid_loss = 0.0
        with torch.no_grad():
            for batch in valid_loader:
                seq = batch['seq'].to(device)
                image = batch['image'].to(device)
                target = batch['target'].to(device)
                pressure = batch['pressure'].to(device)

                wind_pred, rmw_pred = model(seq, image)

                loss_wind = criterion(wind_pred, target[:, 0]).item()
                loss_rmw = criterion(rmw_pred, target[:, 1]).item()
                # reg_loss = model.regularization_loss(regularize_activation=0.1, regularize_entropy=0.1).item()
                # total_loss = (TrainConfig.loss_weights[0] * loss_wind +
                #               TrainConfig.loss_weights[1] * loss_rmw +
                #               reg_loss * TrainConfig.reg_weight)
                total_loss = TrainConfig.loss_weights[0] * loss_wind + TrainConfig.loss_weights[1] * loss_rmw
                valid_loss += total_loss

        avg_valid_loss = valid_loss / len(valid_loader)
        valid_losses.append(avg_valid_loss)
        scheduler.step(avg_valid_loss)

        print(
            f"Epoch [{epoch + 1}/{TrainConfig.epochs}] | "
            f"Train Loss: {avg_train_loss:.4f} | "
            f"Valid Loss: {avg_valid_loss:.4f} | "
            f"LR: {optimizer.param_groups[0]['lr']:.6f}"
        )

        # 模型保存逻辑（添加_deploy后缀）
        def save_checkpoint(epoch_num, trigger_type):
            current_time = datetime.datetime.now().strftime("%m%d%H%M")
            filename = f"checkpoint_{epoch_num}_{trigger_type}_{current_time}.pth"  # 修改点4

            save_path = os.path.join(run_dir, filename)

            torch.save({
                'epoch': epoch_num,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
                'train_losses': train_losses,
                'valid_losses': valid_losses
            }, save_path)
            print(f"Saved checkpoint to {save_path}")

        if avg_valid_loss <= TrainConfig.early_stop_threshold:
            print(f"Early stopping triggered at epoch {epoch + 1}")
            save_checkpoint(epoch + 1, "earlystop")
            break

        if (epoch + 1) % TrainConfig.save_interval == 0 or epoch == TrainConfig.epochs - 1:
            save_checkpoint(epoch + 1, "scheduled")

    # 保存损失曲线到_deploy路径
    plt.figure(figsize=(10, 6))
    plt.plot(train_losses, label='Training Loss')
    plt.plot(valid_losses, label='Validation Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training and Validation Loss Curves (Deploy)')
    plt.legend()

    fig_path = os.path.join(PathConfig.fig_save_path, "loss_curves.png")  # 修改点2
    plt.savefig(fig_path)
    plt.close()
    print(f"Saved loss curves to {fig_path}")


if __name__ == "__main__":
    train()